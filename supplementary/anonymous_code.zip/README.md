# Anonymous Verification Tools

This supplementary package contains a minimal Python implementation of the
verification-floor, holdout-sizing, active-floor, and pipeline-depth utilities
used in the paper.

Installation:

```bash
pip install .
```

Example:

```python
from verification_tools import verification_floor, holdout_size
```
